<?php
$con=mysqli_connect("sql212.byethost24.com","b24_17136188","Dag12Avond13","b24_17136188_247");
// $con=mysqli_connect("127.0.0.1","root","","247center");
mysqli_set_charset($con,"utf8");
// $con=mysqli_connect("mysql.loomhost.com","u528317616_aval","draca13rais04","u528317616_fakt";
// $con=mysqli_connect("sql309.byethost13.com","u528317616_aval","draca13rais04","u528317616_fakt";
?>