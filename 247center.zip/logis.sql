-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 21, 2014 at 07:26 PM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `logis`
--

-- --------------------------------------------------------

--
-- Table structure for table `artikal`
--

CREATE TABLE IF NOT EXISTS `artikal` (
  `SIFA` text,
  `NAZA` text,
  `JEDM` text,
  `VPC` decimal(8,2) DEFAULT NULL,
  `MARG` decimal(4,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=cp1250;

--
-- Dumping data for table `artikal`
--

INSERT INTO `artikal` (`SIFA`, `NAZA`, `JEDM`, `VPC`, `MARG`) VALUES
('112', 'rerna', 'kom', '13456.09', '12.09'),
('114', 'fen sss', 'kom', '1345.09', '12.56'),
('115', 'sss', 'dd', '11223.00', '12.00'),
('116', 'mikina djokica', 'dd', '344.00', '12.00');

-- --------------------------------------------------------

--
-- Table structure for table `kateg`
--

CREATE TABLE IF NOT EXISTS `kateg` (
  `SIFKT` int(11) NOT NULL,
  `NAZKT` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=cp1250;

--
-- Dumping data for table `kateg`
--

INSERT INTO `kateg` (`SIFKT`, `NAZKT`) VALUES
(111, 0);

-- --------------------------------------------------------

--
-- Table structure for table `kif`
--

CREATE TABLE IF NOT EXISTS `kif` (
  `RBRF` int(11) DEFAULT NULL,
  `DATIZ` text,
  `DATP` text,
  `IDKL` text,
  `VRFAK` text,
  `OPIS` text,
  `CENA` decimal(6,2) DEFAULT NULL,
  `PDV` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=cp1250;

-- --------------------------------------------------------

--
-- Table structure for table `klijenti`
--

CREATE TABLE IF NOT EXISTS `klijenti` (
  `IDKL` text,
  `NAZKL` text,
  `ADRKL` text,
  `MESTO` text,
  `PIB` text,
  `MAT` text,
  `FIKS` text,
  `EMAIL` text,
  `IMEVL` text,
  `MOBVL` text
) ENGINE=InnoDB DEFAULT CHARSET=cp1250;

--
-- Dumping data for table `klijenti`
--

INSERT INTO `klijenti` (`IDKL`, `NAZKL`, `ADRKL`, `MESTO`, `PIB`, `MAT`, `FIKS`, `EMAIL`, `IMEVL`, `MOBVL`) VALUES
('11232', 'ddd', 'sddssssssssssssssssssss', 'sdddsssssssssssssssssssssssssssss', 'dd', 'ddd', 'dd', 'ddd', 'ddd', 'ddd');

-- --------------------------------------------------------

--
-- Table structure for table `kpr`
--

CREATE TABLE IF NOT EXISTS `kpr` (
  `RBRF` int(11) DEFAULT NULL,
  `DATIZ` text,
  `PROD` text,
  `OPIS` text,
  `CENA` decimal(6,2) DEFAULT NULL,
  `PDV` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=cp1250;

-- --------------------------------------------------------

--
-- Table structure for table `usluge`
--

CREATE TABLE IF NOT EXISTS `usluge` (
  `SIFU` text NOT NULL,
  `NAZU` text NOT NULL,
  `CENA` decimal(8,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=cp1250;

--
-- Dumping data for table `usluge`
--

INSERT INTO `usluge` (`SIFU`, `NAZU`, `CENA`) VALUES
('1111', 'miki', '2232.00');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
