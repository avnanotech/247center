function obilasci(){
	
	
}